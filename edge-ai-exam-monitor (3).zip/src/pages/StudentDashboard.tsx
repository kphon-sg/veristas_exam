import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  CheckCircle2, 
  Trophy, 
  BarChart3, 
  Clock, 
  Calendar as CalendarIcon,
  ChevronRight,
  Bell,
  Search,
  ArrowUpRight,
  MoreHorizontal,
  ScanFace,
  TrendingUp,
  User as UserIcon,
  GraduationCap,
  MapPin,
  Calendar
} from 'lucide-react';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { ProgressBar } from '../components/ui/ProgressBar';
import { Badge } from '../components/ui/Badge';
import { Avatar } from '../components/ui/Avatar';
import { Table, TableRow, TableCell } from '../components/ui/Table';

import { useParams, useNavigate } from 'react-router-dom';

export const StudentDashboard = ({ user: authUser, onQuizSelect }: { user: any, onQuizSelect?: (quiz: any) => void }) => {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [pendingQuizzes, setPendingQuizzes] = useState<any[]>([]);
  const [stats, setStats] = useState({
    totalAssigned: 0,
    completedCount: 0,
    pendingCount: 0,
    averageScore: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem('veritas_token');
        const headers = { 'Authorization': `Bearer ${token}` };

        // 1. Fetch Dashboard Overview (Profile)
        const overviewRes = await fetch('/api/student/dashboard-overview', { headers });
        const overviewData = await overviewRes.json();
        if (overviewData.profile) setProfile(overviewData.profile);

        // 2. Fetch Dashboard Stats
        const statsRes = await fetch('/api/student/dashboard-stats', { headers });
        const statsData = await statsRes.json();
        if (!statsData.error) setStats(statsData);

        // 3. Fetch Pending Quizzes (Upcoming only for the list)
        const pendingRes = await fetch('/api/student/pending-quizzes?upcomingOnly=true', { headers });
        const pendingData = await pendingRes.json();
        setPendingQuizzes(pendingData);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };

    if (authUser?.id) {
      fetchData();
    }
  }, [authUser]);

  const statCards = [
    { label: 'Total Assigned', value: stats.totalAssigned || 0, icon: BookOpen, trend: 'All courses' },
    { label: 'Completed', value: stats.completedCount || 0, icon: CheckCircle2, trend: `${stats.totalAssigned > 0 ? Math.round((stats.completedCount / stats.totalAssigned) * 100) : 0}% rate` },
    { label: 'Pending', value: stats.pendingCount || 0, icon: Clock, trend: `${stats.pendingCount || 0} urgent` },
    { label: 'Avg. Score', value: `${stats.averageScore || 0}%`, icon: Trophy, trend: 'Overall' },
  ];

  if (loading) {
    return (
      <div className="flex-1 bg-[#f8fafc] min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-500 font-bold animate-pulse">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-[#f8fafc] min-h-screen p-8">
      {/* Header */}
      <header className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-black text-slate-800 tracking-tight">Student Dashboard</h1>
        </div>
        <div className="flex items-center gap-4">
          <button className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-veritas-indigo transition-colors">
            <Search className="w-5 h-5" />
          </button>
          <button className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-veritas-indigo transition-colors relative">
            <Bell className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
            <div className="text-right">
              <p className="text-sm font-black text-slate-800 leading-none">{profile?.fullName || authUser?.full_name || authUser?.username}</p>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Student</p>
            </div>
            <Avatar name={profile?.fullName || authUser?.full_name || authUser?.username} src={profile?.profilePicture || authUser?.profilePicture} className="rounded-xl" />
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto space-y-8">
        {/* Welcome Banner & Profile Info */}
        <Card className="border-none shadow-sm overflow-hidden">
          <CardContent className="p-8 bg-white">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-start gap-6">
                <div className="w-20 h-20 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-200 flex-shrink-0 overflow-hidden">
                  {profile?.profilePicture ? (
                    <img src={profile.profilePicture} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <ScanFace className="w-10 h-10 text-white" />
                  )}
                </div>
                <div className="space-y-4">
                  <div>
                    <h2 className="text-3xl font-black tracking-tight text-slate-800">
                      Welcome back, <span className="text-indigo-600">{profile?.fullName?.split(' ')[0] || authUser?.full_name?.split(' ')[0] || authUser?.username}</span>!
                    </h2>
                    <div className="flex items-center gap-3 mt-1">
                      <Badge variant="success" className="bg-emerald-50 text-emerald-600 border-emerald-100">● Student Account</Badge>
                      <p className="text-slate-400 text-sm font-medium">
                        You have {pendingQuizzes.length} pending quizzes to complete.
                      </p>
                    </div>
                  </div>
                  
                  {/* Detailed Profile Info */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-4 border-t border-slate-50">
                      <div className="space-y-1">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Student ID</p>
                        <div className="flex items-center gap-2 text-slate-700">
                          <UserIcon className="w-3.5 h-3.5 text-indigo-500" />
                          <span className="text-sm font-bold">{profile?.studentCode || 'N/A'}</span>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Department</p>
                        <div className="flex items-center gap-2 text-slate-700">
                          <GraduationCap className="w-3.5 h-3.5 text-indigo-500" />
                          <span className="text-sm font-bold">{profile?.department || 'N/A'}</span>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Age / Year</p>
                        <div className="flex items-center gap-2 text-slate-700">
                          <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                          <span className="text-sm font-bold">
                            {profile?.age && profile.age !== 'N/A' ? `${profile.age} yrs` : ''} 
                            {profile?.yearOfStudy && profile.yearOfStudy !== 'N/A' ? ` (Year ${profile.yearOfStudy})` : ''}
                            {(!profile?.age || profile.age === 'N/A') && (!profile?.yearOfStudy || profile.yearOfStudy === 'N/A') ? 'N/A' : ''}
                          </span>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Location</p>
                        <div className="flex items-center gap-2 text-slate-700">
                          <MapPin className="w-3.5 h-3.5 text-indigo-500" />
                          <span className="text-sm font-bold">{profile?.location || 'N/A'}</span>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
              <div className="flex flex-row md:flex-col gap-3">
                <button className="px-6 py-2.5 bg-white text-slate-600 border border-slate-200 font-bold rounded-xl hover:bg-slate-50 transition-all">Edit Profile</button>
                {pendingQuizzes.filter(q => q.status !== 'EXPIRED').length > 0 && (
              <button 
                onClick={() => onQuizSelect?.(pendingQuizzes.find(q => q.status !== 'EXPIRED'))}
                className="px-6 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:opacity-90 transition-all shadow-lg shadow-indigo-200"
              >
                Start Quiz
              </button>
            )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {statCards.map((stat, i) => (
            <Card key={i} className="border-none shadow-sm">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="w-12 h-12 bg-white border border-slate-100 rounded-xl flex items-center justify-center shadow-sm">
                    <stat.icon className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
                    <h3 className="text-3xl font-black text-slate-800">{stat.value}</h3>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-slate-50">
                  <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">{stat.trend}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-12 gap-8">
          {/* Pending Quizzes */}
          <div className="col-span-12 lg:col-span-8">
            <Card className="h-full border-none shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between border-b border-slate-50">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="w-5 h-5 text-indigo-600" />
                  <h3 className="text-base font-black text-slate-800 tracking-tight">Pending Quizzes</h3>
                </div>
                <button className="text-xs font-bold text-slate-400 hover:text-indigo-600 flex items-center gap-1">
                  View All <ChevronRight className="w-3 h-3" />
                </button>
              </CardHeader>
              <CardContent className="p-0">
                {pendingQuizzes.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table headers={['Quiz Title', 'Course', 'Duration', 'Deadline', 'Action']}>
                      {pendingQuizzes.map((quiz) => (
                        <TableRow key={quiz.id}>
                          <TableCell>
                            <div className="flex flex-col">
                              <p className="text-sm font-bold text-slate-800">{quiz.title}</p>
                              {quiz.status === 'EXPIRED' && (
                                <span className="text-[10px] font-bold text-rose-500 uppercase">Missed / Expired</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className="bg-indigo-50 text-indigo-600 border-none font-bold text-[10px]">
                              {quiz.course_code}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1.5 text-slate-500">
                              <Clock className="w-3.5 h-3.5" />
                              <span className="text-xs font-medium">{quiz.duration_minutes}m</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <p className="text-xs font-bold text-slate-600">
                              {new Date(quiz.deadline).toLocaleDateString()}
                            </p>
                          </TableCell>
                          <TableCell className="text-right">
                            <button 
                              onClick={() => {
                                if (quiz.status !== 'EXPIRED') {
                                  navigate(`/exam/setup/${quiz.id}`);
                                }
                              }}
                              disabled={quiz.status === 'EXPIRED'}
                              className={`${quiz.status === 'EXPIRED' ? 'text-slate-300 cursor-not-allowed' : 'text-indigo-600 hover:text-indigo-700'} font-black text-xs uppercase tracking-wider flex items-center gap-1 ml-auto`}
                            >
                              {quiz.status === 'EXPIRED' ? 'Closed' : 'Start'} <ArrowUpRight className="w-3.5 h-3.5" />
                            </button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </Table>
                  </div>
                ) : (
                  <div className="p-12 flex flex-col items-center justify-center text-center space-y-4">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-10 h-10 text-slate-200" />
                    </div>
                    <div>
                      <h4 className="text-lg font-black text-slate-800">All Caught Up!</h4>
                      <p className="text-slate-400 text-sm font-medium max-w-xs mx-auto">You have no pending quizzes. Great job staying on top of your work!</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Progress Widgets */}
          <div className="col-span-12 lg:col-span-4 space-y-8">
            <Card className="border-none shadow-sm">
              <CardHeader className="border-b border-slate-50">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-emerald-500" />
                  <h3 className="text-base font-black text-slate-800 tracking-tight">Your Progress</h3>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Course Completion</span>
                    <span className="text-sm font-black text-indigo-600">
                      {stats.totalAssigned > 0 ? Math.round((stats.completedCount / stats.totalAssigned) * 100) : 0}%
                    </span>
                  </div>
                  <ProgressBar 
                    value={stats.totalAssigned > 0 ? (stats.completedCount / stats.totalAssigned) * 100 : 0} 
                    className="h-3 bg-slate-100" 
                    color="bg-indigo-600" 
                  />
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    {stats.completedCount} of {stats.totalAssigned} quizzes completed
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      <Trophy className="w-5 h-5 text-indigo-600" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-800">Next Milestone</p>
                      <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">Silver Badge</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] font-bold text-slate-400">
                      <span>Progress</span>
                      <span>75%</span>
                    </div>
                    <ProgressBar value={75} className="h-1.5" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#1a1c23] text-white border-none shadow-lg overflow-hidden relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-600/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
              <CardContent className="p-6 space-y-4 relative z-10">
                <h4 className="text-lg font-black tracking-tight">Need Help?</h4>
                <p className="text-xs text-slate-400 font-medium leading-relaxed">Our support team is available 24/7 to assist you with any technical issues.</p>
                <button className="w-full py-2.5 bg-white/5 border border-white/10 text-white font-bold rounded-xl hover:bg-white/10 transition-all">Contact Support</button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

